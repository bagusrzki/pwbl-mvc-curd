<h2>Tambah Pemesanan</h2>

<form action="Proses" method="post">
    <table>
        <tr>
            <td>ID USER</td>
            <td><input type="text" name="order_id_user"></td>
        </tr>
        <tr>
            <td>KODE</td>
            <td><input type="text" name="order_kode"></td>
        </tr>
        <tr>
            <td>TTL</td>
            <td><input type="text" name="order_ttl"></td>
        </tr>
        <tr>
            <td>KURIR</td>
            <td><input type="text" name="order_kurir"></td>
        </tr>
        <tr>
            <td>ONGKIR</td>
            <td><input type="text" name="order_ongkir"></td>
        </tr>
        <tr>
            <td>BAYAR DEADLINE</td>
            <td><input type="date" name="order_byr_deadline"></td>
        </tr>
        
        <tr>
            <td></td>
            <td><input type="submit" name="btn_simpan" value="SIMPAN"></td>
        </tr>
    </table>
</form>